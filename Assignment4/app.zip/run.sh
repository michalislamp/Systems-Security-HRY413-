#!/bin/bash

export FLASK_DEBUG="FALSE"

rm -rf ./flask_session

python3 app/app.py 


